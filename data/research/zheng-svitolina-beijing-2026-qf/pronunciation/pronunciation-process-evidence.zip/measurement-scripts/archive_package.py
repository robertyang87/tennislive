import json,hashlib,shutil,zipfile,datetime
from pathlib import Path
D=Path('/workspace/tennislive/data/research/zheng-svitolina-beijing-2026-qf/pronunciation');B=Path('/workspace/scratch/zheng-pronunciation/archive-before');B.mkdir(exist_ok=True)
for p in D.glob('*.json'):shutil.copy2(p,B/p.name)
shutil.copy2(D/'FINAL_REVIEW.md',B/'FINAL_REVIEW.md')
# Archive exact executed pack script, too. Production spec/code unchanged.
shutil.copy2(Path(__file__),D/'measurement-scripts/archive_package.py')
m=json.loads((D/'final-text-manifest.json').read_text());am=json.loads((D/'artifact-map.json').read_text());bs=json.loads((D/'bindings.json').read_text());hs={r['text_sha256']:r['utterance']for r in m['utterances']};group={}
names=['pronunciation-process-evidence.zip','pronunciation-finish-evidence.zip']
def assign(rel,n):
 if rel in group:assert group[rel]==n,(rel,group[rel],n)
 group[rel]=n
for p in (D/'evidence').glob('*.json'):
 r=json.loads(p.read_text());h=hashlib.sha256(r['sentence'].encode()).hexdigest();u=hs[h];n=0 if u<=3 else 1;assign(str(p.relative_to(D)),n)
 for ap in r.get('audio',{}).values():
  assign(am[ap]['path'],n)
  mark=str(Path(ap).with_suffix('.json'))
  if mark in am:assign(am[mark]['path'],n)
for b in bs:
 n=0 if b['utterance']<=3 else 1;assign(b['stored_audio'],n);assign(b['stored_wordboundaries'],n)
for p in (D/'measurement-scripts').glob('*'):assign(str(p.relative_to(D)),0)
archive_dirs=['native-audio','reference-audio','evidence','measurement-scripts'];all_members={str(p.relative_to(D))for dn in archive_dirs for p in (D/dn).rglob('*')if p.is_file()};assert set(group)==all_members,(sorted(all_members-set(group)),sorted(set(group)-all_members))
archives=[]
for n,name in enumerate(names):
 dst=D/name;members=sorted(rel for rel,g in group.items()if g==n);meta={}
 with zipfile.ZipFile(dst,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for rel in members:
   p=D/rel;data=p.read_bytes();z.writestr(rel,data);meta[rel]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert dst.stat().st_size<=8_000_000,(name,dst.stat().st_size)
 with zipfile.ZipFile(dst)as z:
  assert z.testzip()is None;assert set(z.namelist())==set(members)
  for rel,v in meta.items():assert hashlib.sha256(z.read(rel)).hexdigest()==v['sha256']
 archives.append({'path':name,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'members':len(members),'logic':'坐标、首盘、第二盘压力与回破，以及完整复现脚本'if n==0 else'抢七、统计、下一轮与片尾','member_inventory':meta})
# All report and measurement paths remain extraction paths, with explicit archive mappings.
for original,q in am.items():q['archive']=names[group[q['path']]];q['path_kind']='zip_member_relative_to_pronunciation_directory'
(D/'artifact-map.json').write_text(json.dumps(am,ensure_ascii=False,indent=2))
for b in bs:
 b['audio_archive']=names[group[b['stored_audio']]];b['wordboundaries_archive']=names[group[b['stored_wordboundaries']]];b['stored_paths_kind']='ZIP内相对路径；解压至本pronunciation目录后保持原路径'
(D/'bindings.json').write_text(json.dumps(bs,ensure_ascii=False,indent=2))
r=json.loads((D/'final-review.json').read_text());r['archives']=[{k:v for k,v in a.items()if k!='member_inventory'}for a in archives];r['archive_member_inventory']='archive-manifest.json';r['transport_note']='引用音频与测量路径为ZIP内路径；在当前pronunciation目录解压两个ZIP后，可按原hash复现。原始测量JSON字节不改，原始绝对音频路径通过artifact-map.json映射到ZIP内相对路径；归档的逐成员SHA256见archive-manifest.json。';r['evidence_paths_kind']='ZIP内相对路径；在当前pronunciation目录解压后可按原hash复现'
for row in r['occurrences']:
 for v in row['comparisons'].values():v['evidence_archive']=names[group[v['evidence']]];v['evidence_path_kind']='zip_member'
(D/'final-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));m['archives']=[{k:v for k,v in a.items()if k!='member_inventory'}for a in archives];m['stored_artifact_paths_kind']='ZIP内相对路径；解压到当前pronunciation目录后按原hash复现';(D/'final-text-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));(D/'archive-manifest.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.UTC).isoformat(),'archives':archives,'extraction':'在当前pronunciation目录解压两个ZIP，保留ZIP内相对目录；所有原始文件字节及SHA256不变','original_default_measurement_results_preserved':True},ensure_ascii=False,indent=2))
md=(D/'FINAL_REVIEW.md').read_text();md+='\n## 原始音频、测量与脚本归档\n\n引用音频与测量路径为 ZIP 内路径；在当前 pronunciation 目录解压下面两个 ZIP 后，可按原 hash 复现。原始默认不可靠记录和所有采用的参照、自测及复现脚本完整保留；原始测量 JSON 字节没有改写。原始绝对路径经 artifact-map.json 映射到 ZIP 内相对路径，逐成员 SHA256 见 archive-manifest.json。\n\n'
for a in archives:md+=f"- `{a['path']}`：{a['bytes']} 字节，SHA256 `{a['sha256']}`；{a['logic']}。\n"
md+='\n例如在本目录执行：\n\n```bash\npython -m zipfile -e pronunciation-process-evidence.zip .\npython -m zipfile -e pronunciation-finish-evidence.zip .\n```\n\n归档尺寸已经实测且分别小于 8,000,000 字节，逐成员解压后的字节 SHA256 已与打包前文件一致性校验通过。\n';(D/'FINAL_REVIEW.md').write_text(md)
# Delete only exact archived duplicates, after byte-preservation and archive-size verification.
for dn in archive_dirs:shutil.rmtree(D/dn)
assets={str(p.relative_to(D)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in D.iterdir()if p.is_file() and p.name!='evidence-sha256.json'};(D/'evidence-sha256.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2))
print({'files_remaining':len(list(D.iterdir())),'archives':[{k:v for k,v in a.items()if k!='member_inventory'}for a in archives],'original_member_count':len(group),'archived_members_byte_hash_verified':True})
