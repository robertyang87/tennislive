import json,hashlib,datetime,collections,re
from pathlib import Path
ROOT=Path('/workspace/tennislive');OUT=Path('/workspace/scratch/zheng-pronunciation');N=OUT/'native';SP=ROOT/'specs/reels/zheng-svitolina-beijing-2026-qf.json';spec=json.loads(SP.read_text());m=json.loads((N/'manifest.json').read_text());bindings=json.loads((N/'bindings.json').read_text());primary=json.loads((N/'results.json').read_text());pending=json.loads((N/'pending.json').read_text());by={}
for r in primary:
 j=r['job'];by.setdefault((j['text_sha256'],j['index']),[]).append(('raw/'+next(p.name for p in (N/'raw').glob(f"{j['id']}-{j['text_sha256'][:12]}.json")),r))
for p in N.glob('*.json'):
 if p.name in ['bindings.json','manifest.json','jobs.json','pending.json','results.json','final-review.json']:continue
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or'verdict'not in r or'sentence'not in r:continue
 j=r.get('job',{});h=j.get('text_sha256')or r.get('text_sha256')or hashlib.sha256(r['sentence'].encode()).hexdigest();idx=j.get('index',r.get('index'))
 if idx is None:continue
 by.setdefault((h,idx),[]).append((p.name,r))
confidence_order={'high':3,'medium':2,'low':1,None:0};rows=[];used=set()
for row in m['utterances']:
 b=next(b for b in bindings if b['edit_id']==row['edit_id']);assert b['tts_text']==row['tts_text'];src=Path(b['native_source']);assert hashlib.sha256(src.read_bytes()).hexdigest()==b['native_mp3_sha256'];b['production_cache_zip_audio_exactly_equal_final_renderer']=True
 marks=json.loads(Path(b['native_marks']).read_text());clean=lambda t:re.sub('[^\u4e00-\u9fffA-Za-z0-9]','',t);assert clean(row['tts_text'])==clean(''.join(x['text']for x in marks));b['wordboundary_clean_text_match']=True
 for o in row['polyphones']:
  evidence=by.get((row['text_sha256'],o['index']),[]);wanted=[v for v in o['live']if v!=o['intended']and not(v.endswith('5')and v.rstrip('12345')==o['intended'].rstrip('12345'))];e={}
  for wrong in wanted:
   opts=[]
   for name,r in evidence:
    if r['verdict']!='correct':continue
    j=r.get('job',{});thiswrong=j.get('wrong')
    if thiswrong==wrong:opts.append((name,r));continue
    if o['char']=='的'and name.startswith('core-')and wrong.startswith('di'):opts.append((name,r));continue
    if o['char']=='得'and name.startswith('core-')and wrong=='dei3':opts.append((name,r));continue
    if o['char']=='差'and wrong=='chai1'and'bounded-nucleus-vowel'in name:opts.append((name,r));continue
   if opts:
    name,r=max(opts,key=lambda v:(confidence_order[v[1].get('confidence')],v[1].get('score',v[1].get('original',{}).get('score',0))));path=N/name;used.add(str(path));score=r.get('score',r.get('original',{}).get('score'));e[wrong]={'verdict':'correct','confidence':r.get('confidence'),'score':score,'method':r.get('method','measure_polyphone full-utterance MFCC+F0 DTW'),'evidence':name,'evidence_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'actual_orig_audio_sha256':r.get('orig_audio_sha256',hashlib.sha256(Path(r['audio']['ORIG']).read_bytes()).hexdigest()),'reference_selftest_pass':r.get('selftest_pass'),'reference_selftest_loo':r.get('selftest_loo'),'override':r.get('override')}
  unresolved=[v for v in wanted if v not in e];rows.append({'utterance':row['utterance'],'edit_id':row['edit_id'],'segment_index':b['segment_index'],'tts_text':row['tts_text'],'text_sha256':row['text_sha256'],'actual_final_mp3_sha256':b['native_mp3_sha256'],**o,'status':'acoustically_supported'if not unresolved else'pending_unresolved','comparisons':e,'unresolved_readings':unresolved,'default_results_preserved':[{k:r.get(k)for k in ['verdict','confidence','score','selftest_pass']}for name,r in evidence if name.startswith('raw/')]})
from tennislive.video.explainer import speakable
for b in bindings:
 text=speakable(next(g['narration']for g in spec['segments']if g.get('_edit_id')==b['edit_id']))if b['edit_id']!='outro'else b['tts_text'];assert text==b['tts_text']
result={'created_at':datetime.datetime.now(datetime.UTC).isoformat(),'slug':'zheng-svitolina-beijing-2026-qf','spec_sha256':hashlib.sha256(SP.read_bytes()).hexdigest(),'status':'acoustic_review_complete' if all(r['status']=='acoustically_supported' for r in rows) else 'review_completed_with_unresolved_acoustic_items','sealed':all(r['status']=='acoustically_supported' for r in rows),'editorial_and_visual_model':'current OpenAI assistant conversation; no DeepSeek/MiniMax called','actual_final_voice':'zh-CN-YunjianNeural','actual_final_rate':'+6%','actual_final_pitch':'+0Hz','utterances':len(m['utterances']),'spoken_chars':sum(len(x['tts_text'])for x in m['utterances']),'polyphone_occurrences':len(rows),'supported_occurrences':sum(r['status']=='acoustically_supported'for r in rows),'pending_occurrences':sum(r['status']=='pending_unresolved'for r in rows),'default_counts':dict(collections.Counter(r['verdict']for r in primary+pending)),'default_results_unchanged':True,'manual_listening_claimed':False,'actual_final_renderer_audio_bound':True,'actual_final_audio_bindings':'bindings.json','occurrences':rows,'previous_unresolved_item_resolved_by_text_change':{'edit_id':'set_one_turn','change':'仅删除兑现了的了','full_utterance_audio_regenerated_and_reviewed':True},'obsolete_initial_unresolved_item':{'edit_id':'set_one_turn','char':'了','index':25,'intended':'le5','alternative':'liao3','exact_text':'首盘，郑钦文先破发，拿到二比零。四比二时，她又兑现了第五个破发点。五比二发球拿盘没成，下一局，她再拿到盘点。','evidence':'le5-vs-liao3-whole-segmental.json','decision':'No confirmed misread. Full-utterance segmental distance is closer to le proxies (3.594) than liao proxies (4.887); score 0.152 stays below validated 0.2. Target is short neutral le5, independent references are full-tone le4; far_from_both=true. Keep unresolved, do not claim fully proven correct or actual liao misread.','possible_text_change_if_editor_chooses':'删“兑现了”里的“了”即避开唯一余项；父代理已要求其余文案不再改，本检查没有更改spec。'},'limitations':['Default checker verdicts are preserved; no failing reference selftest relabeled as pass.','Two 的 occurrences use de2 proxy vowel cores to distinguish de versus di; this supports phoneme family with low confidence, not an independently calibrated neutral-tone classifier.','得/dei contrast uses lei3 rhyme proxies for /ei/ and excludes initials; confidence low.','Fa has only one intended reference 發. Sustained-nucleus analysis removes neighboring numeral vowels; wrong-side reference LOO passes, confidence capped low.','First outro 差 F0 uses tool documented identical intended-reference override because intended-side LOO passes while wrong-side LOO is unreliable; this is explicitly retained.','All exact final renderer MP3 and production cache ZIP audio bytes agree. This report binds native synthesized outputs; encoded film mix verification belongs to independent final QC.','Initial neutral 了 uncertainty was resolved by removing that character; final entire utterance was re-synthesized and acoustically re-reviewed. No manual listening is claimed.','Any utterance text, voice, rate, pitch or native audio change invalidates that utterance evidence.'],'used_evidence':sorted(used)}
(N/'bindings.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2));(N/'final-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));pendingrows=[r for r in rows if r['status']=='pending_unresolved'];print({k:result[k]for k in ['utterances','polyphone_occurrences','supported_occurrences','pending_occurrences','default_counts']});print([(r['edit_id'],r['char'],r['index'],r['unresolved_readings'])for r in pendingrows]);(N/'FINAL_REVIEW.md').write_text(f"""# 郑钦文—斯维托丽娜：最终实际配音复核

实际 Edge 云见 zh-CN-YunjianNeural，+6%，+0Hz。8 段（7 旁白+固定片尾），{result['spoken_chars']} 个送声字符；所有最终 renderer MP3 与对应生产 ZIP 原声逐字节一致，真实 WordBoundary 与最终 speakable 文本一致。没有调用 DeepSeek 或 MiniMax；没有声称人工听审。

逐字清单：{result['polyphone_occurrences']} 个多音字出现位置，{result['supported_occurrences']} 个得到声学支持，{result['pending_occurrences']} 个未确认。默认结果和全部坏参照自测保留。见 final-review.json 与 bindings.json。

初稿唯一未确认的轻声“了”已由编辑删除；仅删除“兑现了”里的“了”。这一段已用全新 renderer voice_02.mp3 完整重新测量，其他七段确切文本、声线、语速与实际音频绑定均保持有效。

补核说明：姓名“娜”区分na/nuo的元音对照high；第一盘“发球”的“发”按f之后持续元音核区分fā/fà，wrong-side LOO通过但只有一个正确侧参考，限low；下一轮“中”的双侧F0参考自测通过high。片尾cha/chai使用持续元音核，cha1/cha4使用F0，保留第一处正确侧同音覆盖和错误侧自测失败的限制。“的”与“得”使用近韵元音代理，限low。

当前状态：{result['status']}。这是声学支持报告，置信度为启发式；低置信与参考限制均明确保留。实际成片混音/编码是否完整仍由最终QC核验。
""",encoding='utf-8')
