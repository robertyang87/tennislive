import sys,os,json,hashlib,datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path('/workspace/tennislive');OUT=Path('/workspace/scratch/zheng-pronunciation');sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tools')]
os.environ['POLYPHONE_CACHE']=str(OUT/'audio')
import measure_polyphone as mp
import check_polyphones as cp
from tennislive.video.explainer import speakable
from tennislive.video.outro_page import NARRATION
SP=ROOT/'specs/reels/zheng-svitolina-beijing-2026-qf.json';spec=json.loads(SP.read_text());rows=[];jobs=[];pending=[]
for i,g in [(i,g) for i,g in enumerate(spec['segments']) if g.get('narration')]+[('outro',{'_edit_id':'outro','narration':NARRATION})]:
 txt=speakable(g['narration']);want,words,lex,touched=cp._readings(txt);occ=[];n=len(rows);h=hashlib.sha256(txt.encode()).hexdigest()
 for idx,ch in enumerate(txt):
  yes,defaults,live=cp.poly_info(ch)
  if not yes:continue
  intent=want[idx]; alternatives=[r for r in live if r!=intent and not(r.endswith('5') and r.rstrip('12345')==intent.rstrip('12345'))]
  o={'index':idx,'char':ch,'word':words[idx],'intended':intent,'live':list(live),'defaults':list(defaults)};occ.append(o)
  ok,note=mp.suggest_homophones(intent,exclude=ch,k=3)
  if ch=='发':ok=['發']
  for wrong in alternatives:
   bad,bnote=mp.suggest_homophones(wrong,exclude=ch,k=3)
   if ch=='发':bad=['髮','珐']
   j={'id':f'u{n:02d}-i{idx:02d}-{ch}-{intent}-vs-{wrong}','utterance':n,'edit_id':g['_edit_id'],'sentence':txt,'text_sha256':h,'index':idx,'char':ch,'word':words[idx],'intended':intent,'wrong':wrong,'ok':ok,'bad':bad,'ok_reference_note':note,'bad_reference_note':bnote}
   if not ok or not bad:pending.append({**j,'verdict':'skipped','why':'缺少独立同音参考，未声学确认'})
   else:jobs.append(j)
 rows.append({'utterance':n,'segment_index':i,'edit_id':g['_edit_id'],'display_text':g['narration'],'tts_text':txt,'text_sha256':h,'voice':'zh-CN-YunjianNeural','rate':'+6%','pitch':'+0Hz','polyphones':occ})
manifest={'created_at':datetime.datetime.now(datetime.UTC).isoformat(),'spec_sha256':hashlib.sha256(SP.read_bytes()).hexdigest(),'utterances':rows,'method':'whole final speakable utterance, all live polyphone occurrences, Edge Yunjian +6%; no ASR/listening assertion','cover_speech':False,'sealed':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(OUT/'jobs.json').write_text(json.dumps(jobs,ensure_ascii=False,indent=2));(OUT/'pending.json').write_text(json.dumps(pending,ensure_ascii=False,indent=2))
print('utterances',len(rows),'occurrences',sum(len(r['polyphones'])for r in rows),'jobs',len(jobs),'skipped',len(pending),flush=True)
bindings=[]
for row in rows:
 audio,marks=mp.synth(row['tts_text'],row['voice'],row['rate']);bindings.append({**{k:row[k]for k in ['utterance','segment_index','edit_id','tts_text','text_sha256','voice','rate','pitch']},'mp3':str(audio),'mp3_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'marks':marks,'source':'this exact input synthesized through production Edge backend; final renderer comparison still required'})
(OUT/'bindings.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2))
def one(j):
 p=OUT/'raw'/f"{j['id']}-{j['text_sha256'][:12]}.json";p.parent.mkdir(exist_ok=True)
 if p.exists():return json.loads(p.read_text())
 try:r=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index'])
 except Exception as e:r={'verdict':'error','why':str(e)}
 r={'job':j,**r};r['orig_audio_sha256']=bindings[j['utterance']]['mp3_sha256'];p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
rs=[]
with ThreadPoolExecutor(max_workers=3) as pool:
 for f in as_completed([pool.submit(one,j)for j in jobs]):
  r=f.result();rs.append(r);print(r['job']['id'],r['verdict'],r.get('confidence'),r.get('score'),flush=True)
rs.sort(key=lambda r:r['job']['id']);(OUT/'results.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2));counts={}
for r in rs+pending:counts[r['verdict']]=counts.get(r['verdict'],0)+1
s={'counts':counts,'utterances':len(rows),'occurrences':sum(len(r['polyphones'])for r in rows),'status':'pending'if pending or any(r['verdict']!='correct'for r in rs)else'acoustic_review_complete','spec_sha256':manifest['spec_sha256'],'manual_listening_claimed':False,'final_renderer_audio_binding':'not yet available'};(OUT/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2));print(s,flush=True)
