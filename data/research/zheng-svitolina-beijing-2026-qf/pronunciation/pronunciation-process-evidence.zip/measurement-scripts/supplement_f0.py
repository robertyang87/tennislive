import sys,os,json,numpy as np
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio';import measure_polyphone as mp
mp.combined=lambda d:float(d['f0'])if np.isfinite(d['f0'])else float('nan');OUT=Path('/workspace/scratch/zheng-pronunciation')
for p in (OUT/'raw').glob('*.json'):
 b=json.loads(p.read_text());j=b['job']
 if b['verdict']=='correct'or j['char']not in ['发','差']:continue
 if j['char']=='差'and j['wrong']!='cha4':continue
 r=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);r['job']=j;r['method']='F0-only semitone distances for same phoneme, different tone; full utterance MFCC DTW preserves alignment; independent reference LOO required'
 (OUT/f"f0-{j['id']}.json").write_text(json.dumps(r,ensure_ascii=False,indent=2));print(j['id'],r['verdict'],r['confidence'],r['score'],r['selftest_loo'],flush=True)
