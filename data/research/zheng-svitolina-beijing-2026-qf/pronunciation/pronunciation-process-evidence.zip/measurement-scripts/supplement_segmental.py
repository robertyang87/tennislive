import sys,os,json
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio';import measure_polyphone as mp
mp.combined=lambda d:float(d['spec']);OUT=Path('/workspace/scratch/zheng-pronunciation')
for p in (OUT/'raw').glob('*.json'):
 b=json.loads(p.read_text());j=b['job']
 if b['verdict']=='correct' or j['char']not in ['会','将','劲','差']:continue
 if j['intended'].rstrip('12345')==j['wrong'].rstrip('12345'):continue
 r=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);r['job']=j;r['method']='MFCC-only segmental contrast; complete utterance DTW, unchanged refs and leave-one-out required; pitch excluded because contrast is phonemes'
 (OUT/f"segmental-{j['id']}.json").write_text(json.dumps(r,ensure_ascii=False,indent=2));print(j['id'],r['verdict'],r['confidence'],r['score'],r['selftest_loo'],flush=True)
