import sys,os,json,hashlib,numpy as np
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio'
import measure_polyphone as mp
OUT=Path('/workspace/scratch/zheng-pronunciation');rows=json.loads((OUT/'manifest.json').read_text())['utterances'];targets=[]
for row in rows:
 for o in row['polyphones']:
  if o['char']in['的','了','得']:
   if o['char']=='的':A=['德','锝'];B=['低','滴','帝','第'];reason='neutral de compared segmentally with de2 proxy references versus di1/di4; confirms e versus i vowel, not a calibrated neutral-tone classification'
   elif o['char']=='了':A=['泐','鳓'];B=['缭','寥'];reason='neutral le compared segmentally with le4 proxies versus liao2; confirms e versus iao vowel, not a calibrated neutral-tone classification'
   else:A=['德','锝'];B=['磊','垒'];reason='de2 versus dei3 supplemental /e/ versus /ei/ nucleus contrast; lei3 rhyme proxies replace initial d, core excludes initials'
   targets.append((row,o,A,B,reason))
def run(target):
 row,o,Achars,Bchars,reason=target;idx=o['index'];s=row['tts_text'];p=OUT/f"core-u{row['utterance']:02d}-i{idx:02d}-{o['char']}.json"
 if p.exists():return json.loads(p.read_text())
 tracks={};vec={};feats={};audio={};wins={}
 for k,c in [('ORIG',None)]+[(f'A:{c}',c)for c in Achars]+[(f'B:{c}',c)for c in Bchars]:
  txt=s if c is None else s[:idx]+c+s[idx+1:];ap,marks=mp.synth(txt,'zh-CN-YunjianNeural','+6%');a,z,tok=mp.char_window(txt,marks,idx);f=mp.features(mp.load_wav(ap));t=np.arange(len(f['st']))*.01
  start=a+.35*(z+.05-a);end=a+.85*(z+.05-a);ix=np.flatnonzero((t>=start)&(t<=end));feats[k]=f;wins[k]=ix;audio[k]=str(ap);tracks[k]={'wordboundary':[a,z,tok],'core_s':[start,end],'frames':ix.tolist()}
 allspec=np.vstack([f['spec'][f['rms']>.1*np.max(f['rms'])]for f in feats.values()]);mu=allspec.mean(0);sd=allspec.std(0)+1e-6
 for k,f in feats.items():vec[k]=((f['spec'][wins[k]]-mu)/sd).mean(0)
 A=[k for k in vec if k.startswith('A:')];B=[k for k in vec if k.startswith('B:')]
 def score(k):
  d=lambda x:float(np.linalg.norm(vec[k]-vec[x]));da=min((d(x)for x in A if x!=k),default=float('nan'));db=min((d(x)for x in B if x!=k),default=float('nan'));v=(db-da)/(db+da);return{'d_intended':da,'d_wrong':db,'score':v,'got':'correct'if v>=.2 else'misread'if v<=-.2 else'uncertain'}
 loo={k:{'expected':'correct'if k in A else'misread',**score(k)}for k in A+B};passed=all(r['expected']==r['got']for r in loo.values());orig=score('ORIG');r={'job':{'utterance':row['utterance'],'index':idx,'char':o['char'],'intended':o['intended'],'edit_id':row['edit_id']},'sentence':s,'text_sha256':row['text_sha256'],'voice':'zh-CN-YunjianNeural','rate':'+6%','index':idx,'audio':audio,'orig_audio_sha256':hashlib.sha256(Path(audio['ORIG']).read_bytes()).hexdigest(),'method':'target WordBoundary middle 35..85% with 50ms end compensation; standardised MFCC+delta vowel core; paired leave-one-out; no F0','reading_reason':reason,'tracks':tracks,'selftest_loo':loo,'selftest_pass':passed,'original':orig,'verdict':orig['got']if passed else'unreliable','confidence':'low'if passed else None,'limitations':['references compare segmental phoneme family; neutral-tone target has no independent single-reading neutral homophone; no manual listening claimed']};p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
with ThreadPoolExecutor(max_workers=3)as pool:
 for f in as_completed([pool.submit(run,t)for t in targets]):
  r=f.result();print(r['job'],r['verdict'],r['original'],r['selftest_loo'],flush=True)
