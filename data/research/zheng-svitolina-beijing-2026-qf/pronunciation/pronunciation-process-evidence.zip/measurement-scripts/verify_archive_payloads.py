"""After extracting both ZIPs in pronunciation/, verify exact preserved bytes."""
import argparse,json,hashlib,zipfile
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));args=ap.parse_args();root=Path(args.root).resolve();manifest=json.loads((root/'archive-manifest.json').read_text());count=0
for archive in manifest['archives']:
 zp=root/archive['path'];assert hashlib.sha256(zp.read_bytes()).hexdigest()==archive['sha256'],zp
 with zipfile.ZipFile(zp)as z:
  assert z.testzip()is None
  for path,meta in archive['member_inventory'].items():
   assert hashlib.sha256(z.read(path)).hexdigest()==meta['sha256'],(zp,path)
   extracted=root/path;assert extracted.exists(),('extract both ZIPs first',extracted)
   assert hashlib.sha256(extracted.read_bytes()).hexdigest()==meta['sha256'],extracted
   count+=1
for binding in json.loads((root/'bindings.json').read_text()):
 assert hashlib.sha256((root/binding['stored_audio']).read_bytes()).hexdigest()==binding['native_mp3_sha256']
 assert hashlib.sha256((root/binding['stored_wordboundaries']).read_bytes()).hexdigest()==binding['native_marks_sha256']
review=json.loads((root/'final-review.json').read_text())
for occurrence in review['occurrences']:
 for evidence in occurrence['comparisons'].values():
  assert hashlib.sha256((root/evidence['evidence']).read_bytes()).hexdigest()==evidence['evidence_sha256']
print(json.dumps({'verified_archive_members':count,'bound_actual_voice_files':8,'supported_polyphone_occurrences':review['supported_occurrences'],'pending_occurrences':review['pending_occurrences']},ensure_ascii=False))
