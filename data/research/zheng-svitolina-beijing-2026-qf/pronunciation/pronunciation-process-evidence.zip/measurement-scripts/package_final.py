import json,hashlib,shutil,datetime
from pathlib import Path
ROOT=Path('/workspace/tennislive');N=Path('/workspace/scratch/zheng-pronunciation/native');D=ROOT/'data/research/zheng-svitolina-beijing-2026-qf/pronunciation';D.mkdir(parents=True,exist_ok=True)
r=json.loads((N/'final-review.json').read_text());assert r['sealed'] and r['pending_occurrences']==0
r.pop('obsolete_initial_unresolved_item',None);evid=set(r['used_evidence']);default=json.loads((N/'results.json').read_text());pending=json.loads((N/'pending.json').read_text());
for z in default:
 j=z['job'];evid.add(str(N/'raw'/f"{j['id']}-{j['text_sha256'][:12]}.json"))
mapping={};assets={};audio_orig={};bs=json.loads((N/'bindings.json').read_text())
def cp(src,rel):
 src=Path(src);dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);h=hashlib.sha256(dst.read_bytes()).hexdigest();mapping[str(src)]={'path':rel,'sha256':h,'bytes':dst.stat().st_size};assets[rel]={'sha256':h,'bytes':dst.stat().st_size};return rel
for b in bs:
 src=Path(b['native_audio']);rel='native-audio/'+src.name;cp(src,rel);audio_orig[str(src)]=rel;b['stored_audio']=rel;b['stored_wordboundaries']=cp(b['native_marks'],'native-audio/'+Path(b['native_marks']).name)
for ep in sorted(evid):
 p=Path(ep);z=json.loads(p.read_text());name=('default-'if p.parent.name=='raw'else'')+p.name;cp(p,'evidence/'+name)
 for k,ap in z.get('audio',{}).items():
  if ap in mapping:continue
  fp=Path(ap);sha=hashlib.sha256(fp.read_bytes()).hexdigest();rel='reference-audio/'+sha[:24]+'.mp3';cp(fp,rel)
  mark=fp.with_suffix('.json')
  if mark.exists()and str(mark)not in mapping:cp(mark,'reference-audio/'+sha[:24]+'.words.json')
 for row in r['occurrences']:
  for v in row['comparisons'].values():
   if v['evidence']==str(p.relative_to(N)):
    v['evidence']='evidence/'+name
r['used_evidence']=sorted(mapping[x]['path']for x in r['used_evidence']);r['artifact_map']='artifact-map.json';r['actual_final_audio_bindings']='bindings.json';r['default_results_files']=['default-results.json','default-skipped.json'];r['transport_note']='Evidence JSON bytes are preserved. Their original absolute audio paths resolve via artifact-map.json into included durable files; SHA256 identifies every included original and reference audio.'
(D/'final-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));(D/'bindings.json').write_text(json.dumps(bs,ensure_ascii=False,indent=2));(D/'final-text-manifest.json').write_text((N/'manifest.json').read_text());(D/'default-results.json').write_text(json.dumps(default,ensure_ascii=False,indent=2));(D/'default-skipped.json').write_text(json.dumps(pending,ensure_ascii=False,indent=2));(D/'artifact-map.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2));shutil.copy2(N/'FINAL_REVIEW.md',D/'FINAL_REVIEW.md')
# Executed analysis scripts, for reproducibility. No production code modified.
for name in ['run.py','native_review.py','native_adapter.py','stats_final.py','set_one_final.py','supplement_f0.py','supplement_segmental.py','supplement_core.py','supplement_outro.py','supplement_tail.py','fa_nucleus.py','final_targeted.py','build_final_complete_report.py','package_final.py']:
 cp(Path('/workspace/scratch/zheng-pronunciation')/name,'measurement-scripts/'+name)
assets={str(p.relative_to(D)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in D.rglob('*')if p.is_file()};(D/'evidence-sha256.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2));print({'directory':str(D),'files':len(assets),'bytes':sum(v['bytes']for v in assets.values()),'native_audio_files':len(list((D/'native-audio').glob('*.mp3'))),'reference_audio_files':len(list((D/'reference-audio').glob('*.mp3'))),'evidence_json_files':len(list((D/'evidence').glob('*.json'))),'status':r['status'],'supported_occurrences':r['supported_occurrences'],'pending_occurrences':r['pending_occurrences']})
