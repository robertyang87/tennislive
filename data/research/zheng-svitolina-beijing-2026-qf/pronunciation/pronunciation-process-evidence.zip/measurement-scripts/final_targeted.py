import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/zheng-pronunciation');import native_adapter as a
mp=a.mp;N=a.N
rs=json.loads((N/'results.json').read_text())
for b in rs:
 j=b['job']
 if j['char']=='娜':
  mp.combined=lambda d:float(d['spec']);ok=j['ok'];bad=j['bad'];tag='name-na-spectral';why='distinct na/nuo vowel; full DTW MFCC-only and identical references; required two-sided reference selftests'
 elif j['edit_id']=='next_round'and j['char']=='中':
  mp.combined=lambda d:float(d['f0']);ok=['忠','终'];bad=['仲','众'];tag='zhong-f0-cleanrefs';why='zhong1/zhong4 F0-only semitone contrast; excludes documented outlier钟 and polyphonic重 from original references; two independent references per side and required LOO'
 else:continue
 r=mp.measure(j['word']or j['char'],j['sentence'],ok,bad,'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);r['job']=j;r['method']=why;r['orig_audio_sha256']=hashlib.sha256(Path(r['audio']['ORIG']).read_bytes()).hexdigest();(N/f"{tag}-{j['text_sha256'][:12]}.json").write_text(json.dumps(r,ensure_ascii=False,indent=2));print(tag,r['verdict'],r['confidence'],r['score'],r['selftest_loo'],flush=True)
# reuse independent core method for final stats 得 only (exact native original override).
code=Path('/workspace/scratch/zheng-pronunciation/supplement_core.py').read_text().replace("OUT=Path('/workspace/scratch/zheng-pronunciation')","OUT=Path('/workspace/scratch/zheng-pronunciation/native')").replace("if o['char']in['的','了','得']:","if row['edit_id']=='full_stats' and o['char']=='得':").replace("core-u{row['utterance']:02d}-i{idx:02d}-{o['char']}.json","core-u{row['utterance']:02d}-i{idx:02d}-{o['char']}-{row['text_sha256'][:12]}.json")
exec(compile(code,'supplement-core-final-stats','exec'),{'__name__':'__main__'})
