import sys,os,json
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/tools','/workspace/tennislive/src'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio'
import measure_polyphone as mp
N=Path('/workspace/scratch/zheng-pronunciation/native');bindings=json.loads((N/'bindings.json').read_text());lookup={r['tts_text']:(Path(r['native_audio']),json.loads(Path(r['native_marks']).read_text()))for r in bindings};fallback=mp.synth

def native_synth(text,voice,rate,pitch='+0Hz'):
 if text in lookup:
  assert (voice,rate,pitch)==('zh-CN-YunjianNeural','+6%','+0Hz');return lookup[text]
 return fallback(text,voice,rate,pitch)
mp.synth=native_synth
