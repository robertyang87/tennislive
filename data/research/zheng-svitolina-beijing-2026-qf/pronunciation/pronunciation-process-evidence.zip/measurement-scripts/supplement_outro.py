import sys,os,json,numpy as np,hashlib
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio';import measure_polyphone as mp
OUT=Path('/workspace/scratch/zheng-pronunciation');s='关注网球时差，时差归我，好球归你。'
for idx in [5,8]:
 tracks={};curves={};audio={};chosen={}
 for k,c in [('ORIG',None)]+[(f'A:{c}',c)for c in ['插','叉']]+[(f'B:{c}',c)for c in ['岔','汊']]:
  text=s if c is None else s[:idx]+c+s[idx+1:];ap,marks=mp.synth(text,'zh-CN-YunjianNeural','+6%');a,z,tok=mp.char_window(text,marks,idx);f=mp.features(mp.load_wav(ap));track=f['st']-np.nanmedian(f['st']);t=np.arange(len(track))*.01;ix=np.flatnonzero((t>=a+.04)&(t<=z+.05)&np.isfinite(track));runs=np.split(ix,np.where(np.diff(ix)>1)[0]+1);runs=[r for r in runs if len(r)>=4]
  audio[k]=str(ap);chosen[k]={'wordboundary':[a,z,tok]}
  if not runs:curves[k]=np.nan;chosen[k]['status']='no_valid_nucleus';continue
  r=runs[0]
  if len(r)>=6:r=r[1:]
  v=track[r];slope=float(np.median([(v[l]-v[k])/(t[r[l]]-t[r[k]])for k in range(len(v))for l in range(k+1,len(v))]));curves[k]=float(np.log(abs(slope)))if slope<0 else np.nan;tracks[k]={'window_s':[float(t[r[0]]),float(t[r[-1]])],'semitones':v.tolist(),'robust_slope_st_per_s':slope};chosen[k]['status']='measured'
 A=['A:插','A:叉'];B=['B:岔','B:汊']
 def score(k):
  da=min((abs(curves[k]-curves[a])for a in A if a!=k),default=float('nan'));db=min((abs(curves[k]-curves[a])for a in B if a!=k),default=float('nan'));v=(db-da)/(db+da);return{'d_intended':da,'d_wrong':db,'score':v,'got':'correct'if v>=.2 else'misread'if v<=-.2 else'uncertain'}
 loo={k:{'expected':'correct'if k in A else'misread',**score(k)}for k in A+B};passed=all(v['expected']==v['got']for v in loo.values());orig=score('ORIG');r={'sentence':s,'voice':'zh-CN-YunjianNeural','rate':'+6%','index':idx,'method':'previous issue independently fixed first sustained nucleus after target onset+40ms within end+50ms, trim first transition frame; log-magnitude of negative Theil-Sen slope; paired reference LOO; first-tone phrase fall differs from fourth-tone fall; original defaults retained','tracks':tracks,'boundary_windows':chosen,'selftest_loo':loo,'selftest_pass':passed,'original':orig,'verdict':orig['got']if passed else'unreliable','confidence':'medium'if passed else None,'audio':audio,'orig_audio_sha256':hashlib.sha256(Path(audio['ORIG']).read_bytes()).hexdigest()};(OUT/f'outro-nucleus-log-slope-i{idx}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(idx,r['verdict'],orig,loo,tracks,flush=True)
 # nucleus vowel tail contrast cha vs chai, separately prepared refs
 vowel_feats={};windows={};vt={};va={}
 for k,c in [('ORIG',None)]+[(f'A:{c}',c)for c in ['插','叉']]+[(f'B:{c}',c)for c in ['钗','拆']]:
  text=s if c is None else s[:idx]+c+s[idx+1:];ap,marks=mp.synth(text,'zh-CN-YunjianNeural','+6%');a,z,tok=mp.char_window(text,marks,idx);f=mp.features(mp.load_wav(ap));t=np.arange(len(f['st']))*.01;ix=np.flatnonzero(np.isfinite(f['st']));runs=np.split(ix,np.where(np.diff(ix)>1)[0]+1);runs=[r for r in runs if len(r)>=4 and t[r[0]]>=a+.04 and t[r[0]]<=z+.08]
  if not runs:continue
  r=runs[0];r=r[t[r]<=z+.05];tail=r[int(len(r)*.6):]
  if len(tail)<2:tail=r[-2:]
  vowel_feats[k]=f;windows[k]=tail;va[k]=str(ap);vt[k]={'wordboundary':[a,z,tok],'nucleus_window':[float(t[r[0]]),float(t[r[-1]])],'tail_window':[float(t[tail[0]]),float(t[tail[-1]])]}
 if not all(k in vowel_feats for k in ['ORIG','A:插','A:叉','B:钗','B:拆']):continue
 allspec=np.vstack([f['spec'][f['rms']>.1*np.max(f['rms'])]for f in vowel_feats.values()]);mu=allspec.mean(0);sd=allspec.std(0)+1e-6;vec={k:((f['spec'][windows[k]]-mu)/sd).mean(0)for k,f in vowel_feats.items()};A=['A:插','A:叉'];B=['B:钗','B:拆']
 def vscore(k):
  da=min((float(np.linalg.norm(vec[k]-vec[a]))for a in A if a!=k),default=float('nan'));db=min((float(np.linalg.norm(vec[k]-vec[a]))for a in B if a!=k),default=float('nan'));v=(db-da)/(db+da);return{'d_intended':da,'d_wrong':db,'score':v,'got':'correct'if v>=.2 else'misread'if v<=-.2 else'uncertain'}
 loo={k:{'expected':'correct'if k in A else'misread',**vscore(k)}for k in A+B};passed=all(v['expected']==v['got']for v in loo.values());orig=vscore('ORIG');r={'sentence':s,'index':idx,'voice':'zh-CN-YunjianNeural','rate':'+6%','method':'prior independently fixed first sustained vowel nucleus starting after target onset+40ms; clipped end+50ms; last40% MFCC+delta mean distinguishes cha vs chai final diphthong, paired reference LOO','tracks':vt,'selftest_loo':loo,'selftest_pass':passed,'original':orig,'verdict':orig['got']if passed else'unreliable','confidence':'medium'if passed else None,'audio':va,'orig_audio_sha256':hashlib.sha256(Path(va['ORIG']).read_bytes()).hexdigest()};(OUT/f'outro-bounded-nucleus-vowel-i{idx}-chai1.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(idx,'chai',r['verdict'],orig,loo,flush=True)
