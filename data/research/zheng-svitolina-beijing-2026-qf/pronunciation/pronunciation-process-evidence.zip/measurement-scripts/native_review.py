import sys,os,json,hashlib,zipfile,shutil,numpy as np
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio';import measure_polyphone as mp
from tennislive.video.tts import tts_content_key
OUT=Path('/workspace/scratch/zheng-pronunciation');N=OUT/'native';N.mkdir(exist_ok=True);FILM=Path('/workspace/tennislive/output/2026-10-09/reel/zheng-svitolina-beijing-2026-qf');b=json.loads((OUT/'bindings.json').read_text());lookup={};bindings=[]
for r in b:
 ap=FILM/('voice_outro.mp3'if r['segment_index']=='outro'else f'voice_{r["segment_index"]:02d}.mp3');k=tts_content_key(r['tts_text'],r['voice'],r['rate'],'+0Hz','','',0.0);p=Path.home()/'.cache/tennislive-tts'/f'{k}-edge-v2.zip'
 with zipfile.ZipFile(p)as z:
  assert ap.read_bytes()==z.read('audio.mp3');marks=json.loads(z.read('marks.json'))
 audio=N/f'{r["edit_id"]}-{r["text_sha256"][:12]}.mp3';shutil.copy2(ap,audio);js=audio.with_suffix('.json');js.write_text(json.dumps(marks,ensure_ascii=False,indent=2));lookup[r['tts_text']]=(audio,marks);a=mp.load_wav(audio);v=mp.load_wav(Path(r['mp3']));assert len(a)==len(v);corr=float(np.corrcoef(a,v)[0,1]);bindings.append({**{k:r[k]for k in ['utterance','segment_index','edit_id','tts_text','text_sha256','voice','rate','pitch']},'native_source':str(ap),'native_audio':str(audio),'native_marks':str(js),'native_mp3_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'native_marks_sha256':hashlib.sha256(js.read_bytes()).hexdigest(),'measured_previous_original_pcm_correlation':corr,'duration':len(a)/16000,'production_cache_key':k,'production_cache_zip_audio_exactly_equal_final_renderer':True})
(N/'bindings.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2));shutil.copy2(OUT/'manifest.json',N/'manifest.json');shutil.copy2(OUT/'jobs.json',N/'jobs.json');shutil.copy2(OUT/'pending.json',N/'pending.json');original=mp.synth

def native_synth(text,voice,rate,pitch='+0Hz'):
 if text in lookup:
  assert (voice,rate,pitch)==('zh-CN-YunjianNeural','+6%','+0Hz');return lookup[text]
 return original(text,voice,rate,pitch)
mp.synth=native_synth
jobs=json.loads((N/'jobs.json').read_text())
def one(j):
 r=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);r={'job':j,**r};r['orig_audio_sha256']=hashlib.sha256(Path(r['audio']['ORIG']).read_bytes()).hexdigest();r['actual_audio_source']='exact final renderer MP3; production cache archive byte equality verified';p=N/'raw'/f"{j['id']}-{j['text_sha256'][:12]}.json";p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
rs=[]
with ThreadPoolExecutor(max_workers=3)as pool:
 for f in as_completed([pool.submit(one,j)for j in jobs]):
  r=f.result();rs.append(r);print(r['job']['id'],r['verdict'],r.get('confidence'),r.get('score'),flush=True)
(N/'results.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2));print('native all jobs completed',len(rs),flush=True)
# Only scientifically appropriate pre-existing independent methods for unresolved phonetic contrasts.
for name in ['supplement_f0.py','supplement_segmental.py','supplement_core.py','supplement_outro.py','supplement_tail.py']:
 text=(OUT/name).read_text().replace("OUT=Path('/workspace/scratch/zheng-pronunciation')","OUT=Path('/workspace/scratch/zheng-pronunciation/native')")
 # keep synthesis cache at original location and use native override
 g={'__name__':'__main__'};exec(compile(text,str(OUT/name),'exec'),g)
print('native supplemental analyses completed',flush=True)
