import sys,json,numpy as np,hashlib
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/tools'];import measure_polyphone as mp
N=Path('/workspace/scratch/zheng-pronunciation/native')
for p in (N/'raw').glob('*u01*发*'):
 b=json.loads(p.read_text());j=b['job']
 if b['verdict']=='correct':continue
 idx=j['index'];s=b['sentence'];vec={};tracks={}
 for k,ap in b['audio'].items():
  txt=s if k=='ORIG'else s[:idx]+k[-1]+s[idx+1:];marks=json.load(open(ap.replace('.mp3','.json')));a,z,tok=mp.char_window(txt,marks,idx);f=mp.features(mp.load_wav(Path(ap)));t=np.arange(len(f['st']))*.01;ix=np.flatnonzero(np.isfinite(f['st']));runs=np.split(ix,np.where(np.diff(ix)>1)[0]+1);runs=[r for r in runs if len(r)>=5 and t[r[0]]>=a+.06 and t[r[0]]<=z+.12]
  if not runs:continue
  r=runs[0];r=r[t[r]<=z+.12];core=r[int(len(r)*.3):max(int(len(r)*.85),int(len(r)*.3)+3)];v=f['st'][core]-np.nanmedian(f['st']);slope=float(np.median([(v[l]-v[k])/(t[core[l]]-t[core[k]])for k in range(len(v))for l in range(k+1,len(v))]));vec[k]=slope;tracks[k]={'wordboundary':[a,z,tok],'nucleus_s':[float(t[r[0]]),float(t[r[-1]])],'middle30to85_s':[float(t[core[0]]),float(t[core[-1]])],'semitones':v.tolist(),'Theil_Sen_slope':slope}
 A=[k for k in vec if k.startswith('A:')];B=[k for k in vec if k.startswith('B:')]
 def score(k):
  da=min((abs(vec[k]-vec[a])for a in A if a!=k),default=float('nan'));db=min((abs(vec[k]-vec[a])for a in B if a!=k),default=float('nan'));v=(db-da)/(db+da);return{'d_intended':da,'d_wrong':db,'score':v,'got':'correct'if v>=.2 else'misread'if v<=-.2 else'uncertain'}
 loo={k:{'expected':'misread',**score(k)}for k in B};passed=len(A)==1 and len(B)>=2 and all(v['expected']==v['got']for v in loo.values());orig=score('ORIG');r={'job':j,'sentence':s,'text_sha256':j['text_sha256'],'index':idx,'voice':'zh-CN-YunjianNeural','rate':'+6%','method':'separate first sustained voiced vowel island starting after WordBoundary onset+60ms within end+120ms: prevents adjacent numeral二 inclusion; middle30..85% Theil-Sen F0 slope; fa only one intended 發 reference so confidence capped low, wrong-reference leave-one-out must pass','tracks':tracks,'selftest_loo':loo,'selftest_pass':passed,'original':orig,'verdict':orig['got']if passed else'unreliable','confidence':'low'if passed else None,'audio':b['audio'],'orig_audio_sha256':hashlib.sha256(Path(b['audio']['ORIG']).read_bytes()).hexdigest()};(N/f"fa-nucleus-{j['id']}.json").write_text(json.dumps(r,ensure_ascii=False,indent=2));print(j['id'],r['verdict'],orig,loo,tracks,flush=True)
