import sys,os,json,hashlib,numpy as np
from pathlib import Path
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio'
import measure_polyphone as mp
OUT=Path('/workspace/scratch/zheng-pronunciation')
for p in (OUT/'raw').glob('*.json'):
 b=json.loads(p.read_text());j=b['job']
 if b['verdict']=='correct' or j['char'] not in ['发','场','中','好','差']:continue
 if j['char']=='差'and j['wrong']!='cha4':continue
 idx=j['index'];s=j['sentence'];tracks={};vec={}
 for k,ap in b['audio'].items():
  txt=s if k=='ORIG'else s[:idx]+k[-1]+s[idx+1:];marks=json.loads(Path(ap.replace('.mp3','.json')).read_text());a,z,tok=mp.char_window(txt,marks,idx);f=mp.features(mp.load_wav(Path(ap)));t=np.arange(len(f['st']))*.01;ix=np.flatnonzero((t>=a+.04)&(t<=z+.05)&np.isfinite(f['st']));tail=ix[-max(3,int(np.ceil(len(ix)*.4))):];v=f['st'][tail]-np.nanmedian(f['st'])
  slope=float(np.median([(v[l]-v[k])/(t[tail[l]]-t[tail[k]])for k in range(len(v))for l in range(k+1,len(v))]));vec[k]=slope;tracks[k]={'wordboundary':[a,z,tok],'all_pitchvalid_times':t[ix].tolist(),'tail_times':t[tail].tolist(),'tail_semitones':v.tolist(),'robust_slope_st_per_s':slope}
 A=[k for k in vec if k.startswith('A:')];B=[k for k in vec if k.startswith('B:')]
 def score(k):
  da=min((abs(vec[k]-vec[a])for a in A if a!=k),default=float('nan'));db=min((abs(vec[k]-vec[a])for a in B if a!=k),default=float('nan'));v=(db-da)/(db+da);return{'d_intended':da,'d_wrong':db,'score':v,'got':'correct'if v>=.2 else'misread'if v<=-.2 else'uncertain'}
 loo={k:{'expected':'correct'if k in A else'misread',**score(k)}for k in A+B if len(A)>1 or k in B};passed=bool(loo)and all(v['expected']==v['got']for v in loo.values());orig=score('ORIG');r={'job':j,'sentence':s,'text_sha256':j['text_sha256'],'voice':'zh-CN-YunjianNeural','rate':'+6%','index':idx,'audio':b['audio'],'orig_audio_sha256':hashlib.sha256(Path(b['audio']['ORIG']).read_bytes()).hexdigest(),'method':'native target WordBoundary +40ms..end+50ms; last 40% of valid pitch frames, minimum 3; Theil-Sen pitch slope; reference LOO required; one intended reference for fa gives low confidence','tracks':tracks,'selftest_loo':loo,'selftest_pass':passed,'original':orig,'verdict':orig['got']if passed else'unreliable','confidence':'low'if len(A)==1 and passed else'medium'if passed else None};(OUT/f"tail-{j['id']}.json").write_text(json.dumps(r,ensure_ascii=False,indent=2));print(j['id'],r['verdict'],r['confidence'],orig,loo,vec,flush=True)
