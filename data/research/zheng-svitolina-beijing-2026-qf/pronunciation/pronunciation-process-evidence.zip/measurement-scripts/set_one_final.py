import sys,os,json,hashlib,zipfile,datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
sys.path[:0]=['/workspace/tennislive/src','/workspace/tennislive/tools'];os.environ['POLYPHONE_CACHE']='/workspace/scratch/zheng-pronunciation/audio';import measure_polyphone as mp,check_polyphones as cp
from tennislive.video.explainer import speakable
from tennislive.video.tts import tts_content_key
ROOT=Path('/workspace/tennislive');OUT=Path('/workspace/scratch/zheng-pronunciation');N=OUT/'native';SP=ROOT/'specs/reels/zheng-svitolina-beijing-2026-qf.json';spec=json.loads(SP.read_text());idx,g=next((i,g)for i,g in enumerate(spec['segments'])if g.get('_edit_id')=='set_one_turn');txt=speakable(g['narration']);h=hashlib.sha256(txt.encode()).hexdigest();key=tts_content_key(txt,'zh-CN-YunjianNeural','+6%','+0Hz','','',0.0);zp=Path.home()/'.cache/tennislive-tts'/f'{key}-edge-v2.zip'
with zipfile.ZipFile(zp)as z:
 audio=z.read('audio.mp3');marks=json.loads(z.read('marks.json'))
ap=N/f'set_one_turn-{h[:12]}.mp3';ap.write_bytes(audio);js=ap.with_suffix('.json');js.write_text(json.dumps(marks,ensure_ascii=False,indent=2));orig=mp.synth
mp.synth=lambda text,voice,rate,pitch='+0Hz':(ap,marks)if text==txt else orig(text,voice,rate,pitch)
want,words,lex,touched=cp._readings(txt);occs=[];jobs=[];pending=[]
for i,ch in enumerate(txt):
 yes,defaults,live=cp.poly_info(ch)
 if not yes:continue
 o={'index':i,'char':ch,'word':words[i],'intended':want[i],'live':list(live),'defaults':list(defaults)};occs.append(o);ok,note=mp.suggest_homophones(want[i],exclude=ch,k=3)
 if ch=='发':ok=['發']
 for wrong in live:
  if wrong==want[i]or(wrong.endswith('5')and wrong.rstrip('12345')==want[i].rstrip('12345')):continue
  bad,bnote=mp.suggest_homophones(wrong,exclude=ch,k=3)
  if ch=='发':bad=['髮','珐']
  j={'id':f'u01-i{i:02d}-{ch}-{want[i]}-vs-{wrong}','utterance':1,'edit_id':'set_one_turn','sentence':txt,'text_sha256':h,'index':i,'char':ch,'word':words[i],'intended':want[i],'wrong':wrong,'ok':ok,'bad':bad,'ok_reference_note':note,'bad_reference_note':bnote}
  if not ok or not bad:pending.append({**j,'verdict':'skipped','why':'缺独立同音参考，未通过'})
  else:jobs.append(j)
new={'utterance':1,'segment_index':idx,'edit_id':'set_one_turn','display_text':g['narration'],'tts_text':txt,'text_sha256':h,'voice':'zh-CN-YunjianNeural','rate':'+6%','pitch':'+0Hz','polyphones':occs};m=json.loads((N/'manifest.json').read_text());m['utterances'][1]=new;m['spec_sha256']=hashlib.sha256(SP.read_bytes()).hexdigest();(N/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));oldjobs=json.loads((N/'jobs.json').read_text());alljobs=[j for j in oldjobs if j['edit_id']!='set_one_turn']+jobs;(N/'jobs.json').write_text(json.dumps(alljobs,ensure_ascii=False,indent=2));oldpending=json.loads((N/'pending.json').read_text());(N/'pending.json').write_text(json.dumps([j for j in oldpending if j['edit_id']!='set_one_turn']+pending,ensure_ascii=False,indent=2));native_src=ROOT/'output/2026-10-09/reel/zheng-svitolina-beijing-2026-qf'/f'voice_{idx:02d}.mp3'
bind=json.loads((N/'bindings.json').read_text());bind[1]={'**final_current_text**':True,**{k:new[k]for k in ['utterance','segment_index','edit_id','tts_text','text_sha256','voice','rate','pitch']},'native_source':str(native_src),'native_audio':str(ap),'native_marks':str(js),'native_mp3_sha256':hashlib.sha256(audio).hexdigest(),'native_marks_sha256':hashlib.sha256(js.read_bytes()).hexdigest(),'production_cache_key':key,'source':'production Edge cache for exact final input; renderer writes these exact bytes on cache hit','production_cache_zip_audio_exactly_equal_final_renderer':native_src.exists()and native_src.read_bytes()==audio};(N/'bindings.json').write_text(json.dumps(bind,ensure_ascii=False,indent=2))
def run(j):
 r=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);r={'job':j,**r};r['orig_audio_sha256']=hashlib.sha256(audio).hexdigest();p=N/'raw'/f"{j['id']}-{h[:12]}.json";p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
rs=[]
with ThreadPoolExecutor(max_workers=3)as pool:
 for f in as_completed([pool.submit(run,j)for j in jobs]):
  r=f.result();rs.append(r);print(r['job']['id'],r['verdict'],r.get('confidence'),r.get('score'),flush=True)
prior=json.loads((N/'results.json').read_text());(N/'results.json').write_text(json.dumps([r for r in prior if r['job']['edit_id']!='set_one_turn']+rs,ensure_ascii=False,indent=2));print('final set-one measured',len(rs),'skipped',len(pending),flush=True)
# Focused supplemental tone/phoneme method only when phonetic contrast makes it meaningful.
for r in rs:
 j=r['job']
 if r['verdict']=='correct':continue
 if j['char'] in ['分','发']:
  mp.combined=lambda d:float(d['f0']);kind='f0'
 elif j['char']in ['会','还']:
  mp.combined=lambda d:float(d['spec']);kind='segmental'
 else:continue
 rr=mp.measure(j['word']or j['char'],j['sentence'],j['ok'],j['bad'],'zh-CN-YunjianNeural','+6%',char=j['char'],at=j['index']);rr['job']=j;rr['method']=kind+' only focused phonetic contrast, same refs and required selftests';(N/f"{kind}-{j['id']}-{h[:12]}.json").write_text(json.dumps(rr,ensure_ascii=False,indent=2));print('supplement',j['id'],rr['verdict'],rr.get('confidence'),rr.get('score'),flush=True)
# Restore default metric for subsequent tools importing this process.
