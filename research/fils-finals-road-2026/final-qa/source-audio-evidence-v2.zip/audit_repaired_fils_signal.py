"""Read actual native final movie + ASS and write identity/ASR evidence; no video encoding."""
from pathlib import Path
import json,hashlib,datetime,sys,re
import numpy as np
from scipy.signal import correlate,correlation_lags
from faster_whisper import WhisperModel,decode_audio
R=Path('/workspace/fils-finals-production/research/audio')
film=Path(sys.argv[1]);native_output=Path(sys.argv[2]);sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
render=json.loads((native_output/'render.json').read_text());actual_sha=sha(film);assert actual_sha==render['film_sha256']
projection=json.loads((native_output/'render_inputs.json').read_text())['projection'];binding=json.loads((native_output/'audio_review_binding.json').read_text());selected=json.loads((R/'six-source-native-handoff.json').read_text());bysha={x['source_sha256']:x for x in selected}
D=R/'actual-final-audit'/actual_sha[:16];D.mkdir(parents=True,exist_ok=True)
def to_seconds(t):
 h,m,s=t.split(':');return float(h)*3600+float(m)*60+float(s)
events=[]
for line in (native_output/'subtitles.ass').read_text().splitlines():
 if line.startswith('Dialogue:'):
  parts=line.split(',',9);events.append({'start':to_seconds(parts[1]),'end':to_seconds(parts[2]),'text':parts[9]})
master=decode_audio(str(film),sampling_rate=16000);jobs=[]
for i,s in enumerate(projection['segments']):
 key=s.get('source')
 if not key:continue
 source_sha=binding['sources'][key];row=bysha[source_sha];packet=json.loads(Path(row['packet_path']).read_text());a,b=row['window'];assert abs(s['start']-a)<1e-6 and abs(s['end']-b)<1e-6
 off=binding['timeline']['offsets'][i];native_len=binding['timeline']['lengths'][i];assert abs(native_len-(b-a))<.041
 cues=[]
 for u in packet['foreground_english']:
  expected_a=off+u['start']-a;expected_b=off+u['end']-a
  candidate=[x for x in events if u['en'] in x['text'] and abs(x['start']-expected_a)<.1];assert len(candidate)==1,(key,u['en'],candidate)
  e=candidate[0];assert abs(e['start']-expected_a)<.011 and abs(e['end']-expected_b)<.011
  cues.append({'en':u['en'],'source':[u['start'],u['end']],'actual_ass':[e['start'],e['end']],'expected_ass':[expected_a,expected_b],'rounding_delta':[round(e['start']-expected_a,6),round(e['end']-expected_b,6)],'source_tail_margin':b-u['end']})
 source=Path(packet['source_identity']['source_path']);assert sha(source)==source_sha
 original=decode_audio(str(source),sampling_rate=16000)[int(a*16000):int(b*16000)];audio=master[int(off*16000):int((off+b-a)*16000)]
 aa=audio-audio.mean();bb=original-original.mean();xc=correlate(aa,bb,mode='full',method='fft');lags=correlation_lags(len(aa),len(bb));mask=abs(lags)<=int(.15*16000);lag=int(lags[mask][np.argmax(xc[mask])]);left=aa[max(lag,0):];right=bb[max(-lag,0):];n=min(len(left),len(right));left=left[:n];right=right[:n];r=float(np.dot(left,right)/(np.linalg.norm(left)*np.linalg.norm(right)));gain=float(np.dot(left,right)/np.dot(right,right))
 job={'segment_id':s.get('_id'),'source_key':key,'source_id':row['source_id'],'source_sha256':source_sha,'source_path':str(source),'source_window':[a,b],'master_window':[off,off+b-a],'native_segment_length':native_len,'packet_sha256':sha(row['packet_path']),'cue_mapping':cues,'best_lag_samples':lag,'best_lag_seconds':lag/16000,'pcm_correlation':r,'linear_gain_fit':gain,'samples_compared':n,'note':'Source/final decoded16000Hz mono PCM compared. Lossy re-encoding differences remain; no bit-identical PCM or manually-heard claim.'}
 jobs.append((job,audio));print('SIGNAL',json.dumps(job,ensure_ascii=False),flush=True)
proof={'status':'actual_sources_and_ass_mapped; authorized_tail_trim_reuses_prior_actual_ASR','film_path':str(film),'film_sha256':actual_sha,'ass_path':str(native_output/'subtitles.ass'),'ass_sha256':sha(native_output/'subtitles.ass'),'binding_sha256':sha(native_output/'audio_review_binding.json'),'source_count':len(jobs),'human_listening_performed':False,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'segments':[x[0] for x in jobs]};assert len(jobs)==6
(D/'signal-and-ass-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')

old=json.loads((R/'first-film-audio-scope-review.json').read_text());oldby={x['source_key']:x for x in old['sources']};newrender=json.loads((native_output/'render.json').read_text())
assert newrender['tts_bundle']['bundle_sha256']==old['tts_bundle_sha256']
oldwords={x['file']:x['sha256'] for x in old['actual_18_word_files']};newwords=[{'file':p.name,'sha256':sha(p)} for p in sorted(native_output.glob('voice_*.words.json'))];assert len(newwords)==18 and {x['file']:x['sha256'] for x in newwords}==oldwords
reuse=[]
for job,_ in jobs:
 original=oldby[job['source_key']];assert job['source_sha256']==original['source_sha256'];assert abs(job['master_window'][0]-original['master_window'][0])<.001
 assert job['pcm_correlation']>.99 and abs(job['best_lag_seconds'])<.041
 if job['source_key']=='paris-r2':assert job['source_window']==[128.12,142.4]
 else:assert job['source_window']==original['source_window']
 assert len(job['cue_mapping'])==len(original['cue_mapping'])
 for a,b in zip(job['cue_mapping'],original['cue_mapping']):
  assert a['en']==b['en'] and a['source']==b['source']
  assert max(abs(x-y) for x,y in zip(a['actual_ass'],b['actual_ass']))<.011
 reuse.append({'source_key':job['source_key'],'source_sha_unchanged':True,'source_start_unchanged':True,'source_end_unchanged':job['source_window'][1]==original['source_window'][1],'actual_master_offset_unchanged':True,'cue_text_and_times_unchanged':True,'original_actual_ASR_reused':True})
for x in old['actual_asr_files']:assert sha(x['path'])==x['sha256']
paris=next(x[0] for x in jobs if x[0]['source_key']=='paris-r2');assert len(paris['cue_mapping'])==1;last=paris['cue_mapping'][0]
assert abs(last['source_tail_margin']-2.24)<.001
assert abs(newrender['film_seconds']-(old['film_seconds']-1.2))<.041
proof.update({'status':'PASS_ACTUAL_REPAIRED_FILM_AUDIO_ASS_AND_REUSED_ASR','native_run_id':newrender.get('production_sla',{}).get('run_id'),'actual_film_bytes':film.stat().st_size,'actual_film_seconds':newrender['film_seconds'],'cue_count':sum(len(j['cue_mapping']) for j,_ in jobs),'max_ass_rounding_error_seconds':max(abs(v) for j,_ in jobs for c in j['cue_mapping'] for v in c['rounding_delta']),'min_source_pcm_correlation':min(j['pcm_correlation'] for j,_ in jobs),'max_absolute_lag_seconds':max(abs(j['best_lag_seconds']) for j,_ in jobs),'source_and_ASR_reuse':reuse,'prior_actual_film_sha256':old['actual_film_sha256'],'prior_actual_ASR_files_verified':old['actual_asr_files'],'new_ASR_run_performed':False,'reuse_reason':'Root authorized only Paris tail trim143.60 to142.40, after all accepted speech ending140.16. Source bytes,19 accepted cue texts/times,18 frozenTTS and other5 source windows unchanged. New actual PCM/ASS identity was independently reverified for all6; previously completed12 actual-film ASR remain valid content evidence. No second full ASR sweep or background-window research performed.','tts_bundle_sha256':newrender['tts_bundle']['bundle_sha256'],'tts_strict_reused':newrender['tts_bundle']['strict_reused'],'word_boundary_files_unchanged':newwords,'word_boundary_count':18,'paris_complete_sentence':{'en':last['en'],'source_range':last['source'],'actual_ASS_range':last['actual_ass'],'selected_source_end':142.4,'source_tail_margin_seconds':2.24,'actual_segment_end':paris['master_window'][1],'actual_cue_to_segment_end_margin':round(paris['master_window'][1]-last['actual_ass'][1],6)},'visual_scope':'Audio/ASS audit only. Root/independent visual reviewer must verify real Paris tail pixels. Arithmetic bound142.40 plus possible0.5 source tail <=142.90 precedes root-observed promotion onset143.25; no claim that this script visually inspected frames.','limitations':'Signal comparison uses decoded16000Hz mono PCM and bounded time alignment, not bit-identical compressed audio or proof of exact gain. Reused/fresh original ASR can misrecognize names or produce stretched low-confidence onsets; approved source cue times are retained and all underlying actual raw remains unchanged. Human listening not performed. This PASS concerns audio/ASS/input preservation, not whole-film visual publication approval.','review_completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
assert proof['cue_count']==19
(D/'signal-and-ass-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');(R/'repaired-film-audio-review.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('FINAL_AUDIO_PASS',str(R/'repaired-film-audio-review.json'),sha(R/'repaired-film-audio-review.json'),flush=True)
