import sys,json,pathlib,hashlib,subprocess,numpy as np,matplotlib
matplotlib.use('Agg');import matplotlib.pyplot as plt;import parselmouth
sys.path.insert(0,'/workspace/tennislive-probe-speed/tools');import measure_polyphone as mp
P=pathlib.Path('/workspace/scratch/guo-IkK3VdqNLaw/voice-independent');O=P/'final';O.mkdir(exist_ok=True)
D=pathlib.Path('/workspace/tennislive-probe-speed/output/2026-10-13/reel/guo-cirstea-wuhan-2026-r1');film=pathlib.Path('/workspace/scratch/guo-IkK3VdqNLaw/final-release/guo-cirstea-wuhan-2026-r1.mp4');sha=hashlib.sha256(film.read_bytes()).hexdigest();assert sha=='210a1d5138a3072d84bbb50b8964fa289813771cbb2d96be48f207ed6865a777'
binding=json.loads((D/'audio_review_binding.json').read_text());ren=json.loads((D/'render.json').read_text());spec=json.loads((D/'render_inputs.json').read_text())['projection'];old=json.loads((P/'independent-review.json').read_text());rows=[];ys={}
for ix in [1,2,4,6,8,12,15,'outro']:
 text='关注网球时差，时差归我，好球归你。' if ix=='outro' else spec['segments'][ix]['narration'];start=ren['cover_seconds']+ren['segments_seconds'] if ix=='outro' else binding['timeline']['offsets'][ix];duration=ren['outro_seconds'] if ix=='outro' else ren['narration_seconds'][str(ix)];wav=O/f'film-voice-{ix}.wav'
 subprocess.run(['ffmpeg','-v','error','-ss',str(start),'-i',str(film),'-t',str(duration),'-ac','1','-ar','16000','-c:a','pcm_s16le','-y',str(wav)],check=True)
 snd=parselmouth.Sound(str(wav));y=snd.values[0];pit=snd.to_pitch_ac(time_step=.005,pitch_floor=50,pitch_ceiling=350,voicing_threshold=.25,silence_threshold=.01,octave_jump_cost=.5);hz=pit.selected_array['frequency'].copy();hz[hz==0]=np.nan;ts=pit.xs();marks=json.loads((D/('voice_outro.words.json' if ix=='outro' else f'voice_{ix:02d}.words.json')).read_text());ys[ix]=(y,ts,hz,start,text,marks)
 for t in old['rows']:
  targetix={'coordinate':2,'fightback':6,'stats_and_question':15,'outro':'outro','first_pressure':4}[t['edit_id']]
  if targetix!=ix:continue
  lo,hi,tok=mp.char_window(text,marks,t['at']);rows.append({'edit_id':t['edit_id'],'char':t['char'],'at':t['at'],'intended':t['intended'],'wrong':t['wrong'],'film_paragraph_start_s':start,'actual_final_word_estimate_relative_s':[lo,hi],'actual_final_word_estimate_absolute_s':[lo+start,hi+start],'token':tok,'paragraph_wav':str(wav),'paragraph_wav_sha256':hashlib.sha256(wav.read_bytes()).hexdigest(),'marks_path':str(D/('voice_outro.words.json' if ix=='outro' else f'voice_{ix:02d}.words.json')),'ix':ix})
for n in range(0,len(rows),3):
 group=rows[n:n+3];fig,axes=plt.subplots(len(group),2,figsize=(13,4*len(group)),squeeze=False)
 for i,r in enumerate(group):
  y,ts,hz,start,text,marks=ys[r['ix']];lo,hi=r['actual_final_word_estimate_relative_s'];x0=max(0,lo-.16);x1=hi+.17;ax=axes[i,0];ax.specgram(y[int(x0*16000):int(x1*16000)],Fs=16000,NFFT=512,noverlap=470,xextent=(x0+start,x1+start),cmap='magma',vmin=-110,vmax=-30);ax.set_ylim(0,3500);ax.axvspan(lo+start,hi+start,alpha=.1,color='cyan');ax.set_title(f"FINAL {r['edit_id']} {r['at']} {r['intended']} vs {r['wrong']} actual film spectrum");ax.set_xlabel('Exact final film seconds');ax.set_ylabel('Hz')
  ax=axes[i,1];sel=(ts>=x0)&(ts<=x1);ax.plot(ts[sel]+start,hz[sel],'.-',color='black');ax.axvspan(lo+start,hi+start,alpha=.1,color='blue');ax.grid();ax.set_ylim(45,260);ax.set_title('Actual final mixed audio Praat raw F0, gaps retained');ax.set_xlabel('Exact final film seconds');ax.set_ylabel('Hz');r['display_region_absolute_s']=[x0+start,x1+start];r['display_pitch_hz']=[None if not np.isfinite(x) else float(x) for x in hz[sel]];r['display_times_absolute_s']=(ts[sel]+start).tolist()
 fig.tight_layout();fig.savefig(O/f'final-pitch-{n//3+1}.png',dpi=140);plt.close(fig)
# bounded actual words for names/numeric sentences plotted as three broad spectrum windows
wanted=[(2,'郭涵煜'),(2,'十二号'),(2,'科斯蒂亚'),(8,'三比六'),(12,'三比一'),(15,'三十记')]
fig,axes=plt.subplots(3,2,figsize=(14,12));other=[]
for ax,(ix,word) in zip(axes.ravel(),wanted):
 y,ts,hz,start,text,marks=ys[ix];at=text.index(word);lo,_,_=mp.char_window(text,marks,at);_,hi,_=mp.char_window(text,marks,at+len(word)-1);x0=max(0,lo-.05);x1=hi+.05;ax.specgram(y[int(x0*16000):int(x1*16000)],Fs=16000,NFFT=512,noverlap=470,xextent=(x0+start,x1+start),cmap='magma',vmin=-110,vmax=-30);ax.set_ylim(0,3500);ax.set_title(f'FINAL numeric/name phrase #{ix} position {at}');ax.set_xlabel('Exact film seconds');other.append({'paragraph_index':ix,'phrase':word,'at':at,'estimated_absolute_window_s':[lo+start,hi+start],'scope':'Actual speech spectrum and syllabic structure only; not lexical ASR proof'})
fig.tight_layout();fig.savefig(O/'final-names-numbers.png',dpi=140)
report={'schema':'exact-final-film-pronunciation-visual-review.v1','film_path':str(film),'film_sha256':sha,'binding_sha256':hashlib.sha256((D/'audio_review_binding.json').read_bytes()).hexdigest(),'render_sha256':hashlib.sha256((D/'render.json').read_bytes()).hexdigest(),'method':'Bounded paragraphs extracted directly from exact final film. Current actual film timeline and paired current WordBoundary words files used. Praat 5 ms floor50 ceiling350 voicing.25; raw spectrogram plots. Contains original mixed audio; no isolated-native equivalence assumed. No new ASR/TTS or threshold mutation.','critical_comparisons':rows,'numeric_name_phrases':other,'human_listening_claimed':False,'automated_pronunciation_pass_claimed':False,'status':'images_ready_pending_actual_visual_review'}
(O/'final-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('final plots ready',len(rows),'critical comparisons')
