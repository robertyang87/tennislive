from pathlib import Path
import json,numpy as np,parselmouth,hashlib,sys,matplotlib
matplotlib.use('Agg');import matplotlib.pyplot as plt
sys.path[:0]=['/workspace/tennislive-probe-speed/tools'];import measure_polyphone as mp
O=Path('/workspace/scratch/guo-IkK3VdqNLaw/final-review/voice-complement');job=json.loads((O/'job.json').read_text());unique={};ys={}
for t in job['rows']:
 key=(t['edit_id'],t['at']);unique.setdefault(key,t)
 wav=t['final_film_paragraph_path']
 if wav not in ys:
  snd=parselmouth.Sound(wav);y=snd.values[0];pit=snd.to_pitch_ac(time_step=.005,pitch_floor=50,pitch_ceiling=350,voicing_threshold=.25,silence_threshold=.01,octave_jump_cost=.5);hz=pit.selected_array['frequency'].copy();hz[hz==0]=np.nan;ys[wav]=(y,pit.xs(),hz)
rows=[]
for t in unique.values():
 marks=json.loads(Path(t['actual_final_words_path']).read_text());lo,hi,tok=mp.char_window(t['sentence'],marks,t['at']);y,ts,hz=ys[t['final_film_paragraph_path']];start=t['paragraph_film_start_s'];rows.append({'edit_id':t['edit_id'],'char':t['char'],'at':t['at'],'intended':t['intended'],'sentence':t['sentence'],'window_relative_s':[lo,hi],'window_absolute_s':[lo+start,hi+start],'native_token':tok,'paragraph_wav_path':t['final_film_paragraph_path'],'paragraph_wav_sha256':t['final_film_paragraph_sha256'],'plot_region_relative_s':[max(0,lo-.12),hi+.15]})
for n in range(0,len(rows),3):
 group=rows[n:n+3];fig,axes=plt.subplots(len(group),2,figsize=(13,len(group)*3.3),squeeze=False)
 for i,r in enumerate(group):
  t=unique[(r['edit_id'],r['at'])];y,ts,hz=ys[t['final_film_paragraph_path']];start=t['paragraph_film_start_s'];lo,hi=r['window_relative_s'];x0,x1=r['plot_region_relative_s'];ax=axes[i,0];ax.specgram(y[int(x0*16000):int(x1*16000)],Fs=16000,NFFT=512,noverlap=470,xextent=(x0+start,x1+start),cmap='magma',vmin=-110,vmax=-30);ax.axvspan(lo+start,hi+start,color='cyan',alpha=.12);ax.set_ylim(0,3500);ax.set_title(f"FINAL {r['edit_id']} at {r['at']} expected {r['intended']}");ax.set_xlabel('Actual final movie seconds');ax.set_ylabel('Hz');ax=axes[i,1];sel=(ts>=x0)&(ts<=x1);ax.plot(ts[sel]+start,hz[sel],'.-',color='black');ax.axvspan(lo+start,hi+start,color='blue',alpha=.12);ax.set_ylim(45,300);ax.grid();ax.set_title('Actual mixed audio Praat F0; unvoiced gaps retained');ax.set_xlabel('Actual final movie seconds');ax.set_ylabel('Hz');r['display_times_absolute_s']=(ts[sel]+start).tolist();r['display_pitch_hz']=[None if not np.isfinite(z)else float(z)for z in hz[sel]];r['plot_file']=str(O/f'actual-complement-{n//3+1}.png')
 fig.tight_layout();fig.savefig(O/f'actual-complement-{n//3+1}.png',dpi=130);plt.close(fig)
(O/'actual-spectrum-index.json').write_text(json.dumps({'schema':'actual-final-complement-spectrum.v1','film_sha256':job['film_sha256'],'rows':rows,'method':'Direct exact-final mixed audio paragraphs, final paired WordBoundary estimated char windows, Praat raw5ms pitch and raw short-time spectrum. No prototype byte identity, no human hearing claims. Diagnostic displays only, not automatic pronunciation pass.'},ensure_ascii=False,indent=2)+'\n');print('ACTUAL_PLOTS',len(rows))
