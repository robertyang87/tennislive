from pathlib import Path
import json,hashlib,sys,datetime
sys.path[:0]=['/workspace/tennislive-probe-speed/tools','/workspace/tennislive-probe-speed/src']
import measure_polyphone as mp
O=Path('/workspace/scratch/guo-IkK3VdqNLaw/final-review/voice-complement');job=json.loads((O/'job.json').read_text());i=int(sys.argv[1]);t=job['rows'][i];refs={};marks=json.loads(Path(t['actual_final_words_path']).read_text());old=t['acoustic'];text=t['sentence'];at=t['at']
for k,path in old.get('audio',{}).items():
 if k=='ORIG':continue
 pp=Path(path);variant=text[:at]+k[2:]+text[at+1:];assert pp.exists();refs[variant]=(pp,json.loads(pp.with_suffix('.json').read_text()))
def synth(s,voice,rate,pitch='+0Hz'):
 assert voice=='zh-CN-YunjianNeural'and rate=='+6%'
 if s==text:
  p=Path(t['final_film_paragraph_path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==t['final_film_paragraph_sha256'];return p,marks
 if s in refs:return refs[s]
 raise RuntimeError('Network forbidden; no preexisting exact control for requested sentence')
mp.synth=synth
try:a=mp.measure(t['word'],text,t['ok_refs'],t['bad_refs'],'zh-CN-YunjianNeural','+6%',char=t['char'],at=at)
except Exception as e:a={'verdict':'unconfirmed_error','why':f'{type(e).__name__}: {e}'}
r={'target_index':i,'edit_id':t['edit_id'],'char':t['char'],'at':at,'intended':t['intended'],'wrong':t['wrong'],'film_sha256':job['film_sha256'],'final_film_paragraph_sha256':t['final_film_paragraph_sha256'],'paragraph_film_start_s':t['paragraph_film_start_s'],'actual_final_words_sha256':t['actual_final_words_sha256'],'local_prototype_audio_sha256':t['local_prototype_audio_sha256'],'actual_final_audio_byte_identity_to_prototype_assumed':False,'old_calibrated_verdict_unchanged':old['verdict'],'old_confidence_unchanged':old.get('confidence'),'current_final_film_audio_acoustic':a,'method':'Same production MFCC+F0 whole-sentence contrast and original fixed margin; baseline replaced by actual final-film mixed waveform and paired final words. All correct/wrong controls exact preexisting frozen sentences, zero new TTS/network. Mixed audio contamination is a limitation; no isolated-native equivalence assumed.','human_listening_claimed':False,'pronunciation_release_pass_claimed':False,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
r['status']='calibrated_current_final_film_audio_supported'if a['verdict']=='correct'and a.get('confidence')in['high','medium']and not a.get('far_from_both')else'current_final_film_audio_unconfirmed'
(O/f'target-{i:02d}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['target_index','edit_id','char','at','status']},ensure_ascii=False),a['verdict'],a.get('confidence'),a.get('score'),flush=True)
