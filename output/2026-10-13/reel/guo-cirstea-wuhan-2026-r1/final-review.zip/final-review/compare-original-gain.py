import json, subprocess, hashlib, datetime
from pathlib import Path
import numpy as np
base=Path('/workspace/scratch/guo-IkK3VdqNLaw')
source=base/'source/IkK3VdqNLaw.mp4'
film=base/'final-release/guo-cirstea-wuhan-2026-r1.mp4'
repo=Path('/workspace/tennislive-probe-speed')
spec_path=repo/'specs/reels/guo-cirstea-wuhan-2026-r1.json'
binding_path=repo/'output/2026-10-13/reel/guo-cirstea-wuhan-2026-r1/audio_review_binding.json'
spec=json.loads(spec_path.read_text());binding=json.loads(binding_path.read_text())
rate=8000;duration=2.;pad=.15

def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pcm(path,start,seconds):
 command=['ffmpeg','-v','error','-ss',str(start),'-i',str(path),'-t',str(seconds),'-vn','-ac','1','-ar',str(rate),'-f','f32le','-']
 return np.frombuffer(subprocess.check_output(command),dtype='<f4').astype(np.float64)
rows=[]
for index,at,label in [(3,30.,'first-set rally'),(14,270.,'victory reaction and native commentary')]:
 seg=spec['segments'][index];offset=binding['timeline']['offsets'][index]
 assert not seg.get('narration') and not seg.get('mute') and not seg.get('bed')
 assert seg.get('speed',1)==1
 assert at-pad>float(seg['start'])+.18 and at+duration+pad<float(seg['end'])-.18
 final_at=offset+at-float(seg['start'])
 src=pcm(source,at-pad,duration+2*pad);dst=pcm(film,final_at,duration)
 assert len(dst)==int(rate*duration)
 products=np.correlate(src,dst,mode='valid')
 cumulative=np.concatenate(([0.],np.cumsum(src*src)))
 energies=cumulative[len(dst):]-cumulative[:-len(dst)]
 final_energy=np.dot(dst,dst)
 correlation=products/np.sqrt(np.maximum(energies*final_energy,1e-30))
 best=int(np.argmax(correlation));aligned=src[best:best+len(dst)]
 gain=float(products[best]/energies[best]);gain_db=20*np.log10(gain)
 source_rms=float(np.sqrt(np.mean(aligned**2)));final_rms=float(np.sqrt(np.mean(dst**2)))
 ratio_db=float(20*np.log10(final_rms/source_rms))
 passing=float(correlation[best])>.97 and abs(gain_db)<.3 and abs(ratio_db)<.3
 rows.append({'segment_index':index,'description':label,'source_start_seconds':at,'film_start_seconds':final_at,'duration_seconds':duration,'source_alignment_shift_ms':round((best/rate-pad)*1000,3),'correlation':float(correlation[best]),'fitted_gain':gain,'fitted_gain_db':float(gain_db),'source_rms':source_rms,'final_rms':final_rms,'rms_ratio_db':ratio_db,'pass':bool(passing)})
result={'kind':'bounded_actual_native_source_gain_comparison','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(source),'film_sha256':sha(film),'binding_sha256':sha(binding_path),'spec_sha256':sha(spec_path),'preserve_source_audio':spec.get('preserve_source_audio'),'source_hash_matches_binding':sha(source)==binding['sources']['main'],'method':'Decode two 2-second source/final windows to mono 8kHz float PCM. Align within +/-150ms for AAC/resampling timing tolerance. Compare least-squares source gain and RMS with codec tolerance <=0.3dB; correlation >0.97. Neither selected window contains Chinese TTS or a dissolve. No full-film decode or re-encode.','windows':rows,'pass':all(r['pass'] for r in rows)}
out=base/'final-review/original-source-gain-comparison.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
